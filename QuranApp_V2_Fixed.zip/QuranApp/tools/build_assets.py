#!/usr/bin/env python3
"""
أدوات بناء ملفات assets للتطبيق (تعمل Offline بعد تجهيزها):

  quran     <tanzil.txt> <out.json>     تحويل ملف بصيغة  sura|aya|text  إلى quran.json
  words     <quran.json> <words.csv>    استخراج الكلمات الفريدة (للمفسّر ليملأ عمود المعنى)
  meanings  <meanings.csv> <out.json>   تحويل CSV (word,meaning) إلى meanings.json
  validate  <quran.json> [--meanings m.json]   فحص: 114 سورة، 6236 آية، تغطية المعاني
  tafsir    <ar_muyassar.txt> <out.json>  تفسير الآية (sura|aya|text) -> tafsir.json
  glosses   <ar_jalalayn.txt> <quran.json> <out.json>   [تجريبي وغير مراجع] مرادفات مستخرجة آلياً من الجلالين؛ لا تضعه في التطبيق دون مراجعة
  demo      <assets_dir>                 بيانات تجريبية (ليست نص القرآن!) لاختبار الواجهة فوراً

النص والتفسير يجب أن يأتيا من مصادر موثوقة، وتأكد من شروط ترخيص كل مصدر.
"""
import argparse, csv, json, re, sys
from collections import Counter
from pathlib import Path

NAMES = ["الفاتحة","البقرة","آل عمران","النساء","المائدة","الأنعام","الأعراف","الأنفال","التوبة","يونس",
"هود","يوسف","الرعد","إبراهيم","الحجر","النحل","الإسراء","الكهف","مريم","طه","الأنبياء","الحج","المؤمنون",
"النور","الفرقان","الشعراء","النمل","القصص","العنكبوت","الروم","لقمان","السجدة","الأحزاب","سبأ","فاطر","يس",
"الصافات","ص","الزمر","غافر","فصلت","الشورى","الزخرف","الدخان","الجاثية","الأحقاف","محمد","الفتح","الحجرات",
"ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة","الحشر","الممتحنة","الصف",
"الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة","المعارج","نوح","الجن","المزمل",
"المدثر","القيامة","الإنسان","المرسلات","النبأ","النازعات","عبس","التكوير","الانفطار","المطففين","الانشقاق",
"البروج","الطارق","الأعلى","الغاشية","الفجر","البلد","الشمس","الليل","الضحى","الشرح","التين","العلق","القدر",
"البينة","الزلزلة","العاديات","القارعة","التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر",
"الكافرون","النصر","المسد","الإخلاص","الفلق","الناس"]

AYAH_COUNTS = [7,286,200,176,120,165,206,75,129,109,123,111,43,52,99,128,111,110,98,135,112,78,118,64,77,227,
93,88,69,60,34,30,73,54,45,83,182,88,75,85,54,53,89,59,37,35,38,29,18,45,60,49,62,55,78,96,29,22,24,13,14,11,
11,18,12,12,30,52,52,44,28,28,20,56,40,31,50,40,46,42,29,19,36,25,22,17,19,26,30,20,15,21,11,8,8,19,5,8,8,11,
11,8,3,9,5,4,7,3,6,3,5,4,5,6]

# يجب أن يطابق QuranRepository.normalize في Kotlin
NOISE = re.compile("[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640\u08D3-\u08FF﴾﴿۝،.]")
ALEF = re.compile("[أإآٱ]")
def normalize(w): return ALEF.sub("ا", NOISE.sub("", w)).strip()

def load_quran(path):
    d = json.loads(Path(path).read_text(encoding="utf-8"))
    return d["surahs"] if isinstance(d, dict) else d

def cmd_quran(a):
    verses = {}
    for line in Path(a.input).read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#"): continue
        s, v, t = line.split("|", 2)
        verses[(int(s), int(v))] = t.strip()
    basmala = verses[(1, 1)]
    surahs, split = [], []
    for i, (name, count) in enumerate(zip(NAMES, AYAH_COUNTS), start=1):
        ayahs = []
        for n in range(1, count + 1):
            if (i, n) not in verses: sys.exit(f"آية ناقصة: {i}:{n}")
            t = verses[(i, n)]
            # بعض نسخ Tanzil تضع البسملة في أول الآية الأولى؛ نفصلها (دون تغيير أي حرف)
            # لتُعرض كترويسة للسورة بدل أن تُحسب جزءاً من الآية.
            # المطابقة بدون تشكيل لأن بعض السور (95 و97) تكتب البسملة بتشكيل مختلف قليلاً
            if n == 1 and i not in (1, 9):
                words, bw = t.split(" "), basmala.split(" ")
                if len(words) > len(bw) and normalize(" ".join(words[:len(bw)])) == normalize(basmala):
                    t = " ".join(words[len(bw):]).strip()
                    split.append(i)
            ayahs.append({"n": n, "t": t})
        surahs.append({"number": i, "name": name, "ayahs": ayahs})
    if split: print(f"فُصلت البسملة من أول آية في {len(split)} سورة")
    out = {"source": "Tanzil Quran Text (Uthmani, Version 1.1) - Copyright (C) 2007-2026 Tanzil Project - "
                     "License: Creative Commons Attribution 3.0 - https://tanzil.net",
           "basmala": basmala, "surahs": surahs}
    Path(a.output).write_text(json.dumps(out, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(f"تم: {len(surahs)} سورة، {sum(len(s['ayahs']) for s in surahs)} آية -> {a.output}")

def cmd_words(a):
    c = Counter()
    for s in load_quran(a.input):
        for ay in s["ayahs"]:
            for w in ay["t"].split():
                n = normalize(w)
                if len(n) >= 2: c[n] += 1
    with open(a.output, "w", encoding="utf-8-sig", newline="") as f:
        wr = csv.writer(f); wr.writerow(["word", "count", "meaning"])
        for w, n in c.most_common(): wr.writerow([w, n, ""])
    print(f"{len(c)} كلمة فريدة -> {a.output}")

def cmd_meanings(a):
    out, seen = {}, set()
    with open(a.input, encoding="utf-8-sig", newline="") as f:
        for row in csv.reader(f):
            if len(row) < 2 or row[0].strip().lower() == "word": continue
            w, m = row[0].strip(), row[-1].strip() if len(row) > 2 else row[1].strip()
            if not w or not m: continue
            k = normalize(w)
            if k in seen: continue
            seen.add(k); out[w] = m
    Path(a.output).write_text(json.dumps(out, ensure_ascii=False, indent=0), encoding="utf-8")
    print(f"{len(out)} كلمة -> {a.output}")

def cmd_validate(a):
    surahs = sorted(load_quran(a.input), key=lambda s: s["number"])
    ok = True
    if len(surahs) != 114: print(f"خطأ: عدد السور {len(surahs)}"); ok = False
    for s, exp in zip(surahs, AYAH_COUNTS):
        if len(s["ayahs"]) != exp: print(f"خطأ: سورة {s['number']} فيها {len(s['ayahs'])} بدل {exp}"); ok = False
        for ay in s["ayahs"]:
            if not ay["t"].strip(): print(f"نص فارغ {s['number']}:{ay['n']}"); ok = False
    print(f"السور: {len(surahs)} | الآيات: {sum(len(s['ayahs']) for s in surahs)} (المتوقع 6236)")
    if a.meanings:
        keys = {normalize(k) for k in json.loads(Path(a.meanings).read_text(encoding='utf-8'))}
        words = {normalize(w) for s in surahs for ay in s["ayahs"] for w in ay["t"].split()}
        words = {w for w in words if len(w) >= 2}
        print(f"تغطية المعاني (تطابق مباشر): {len(words & keys)} من {len(words)} كلمة فريدة")
    sys.exit(0 if ok else 1)


SOURCES = {
    "ar.muyassar": "Tanzil.net - Tafsir al-Muyassar (King Fahad Quran Complex)",
    "ar.jalalayn": "Tanzil.net - Tafsir al-Jalalayn (al-Mahalli & as-Suyuti)",
}

def read_pipe(path):
    d = {}
    for line in Path(path).read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.count("|") < 2: continue
        s_, v, t = line.split("|", 2)
        d[(int(s_), int(v))] = t.strip()
    return d

def cmd_tafsir(a):
    d = read_pipe(a.input)
    out = {"_source": SOURCES["ar.muyassar"]}
    for (s_, v), t in sorted(d.items()):
        if t: out[f"{s_}:{v}"] = t
    Path(a.output).write_text(json.dumps(out, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(f"{len(out) - 1} آية -> {a.output}")

# كلمات وظيفية لا تُعامل كـ "غريب"
STOP = {normalize(w) for w in """قال قالوا قالت يقول يقولون ذلك هذا هذه تلك هؤلاء أولئك الذين الذي التي ما من إن أن لا لم لن قد هو هم هي
هن نحن أنا أنت أنتم كذلك إذا إذ ثم بل لو لولا كان كانوا كانت يكون تكون على في عن إلى مع هل أم أو ألا إنما كل بعض
هنا هناك حتى لكن غير بين بعد قبل عند له لهم لها لك به بها بهم فيها فيه منها منه منهم عليه عليهم عليها إليه إليهم
الله ربنا ربك ربكم أي كيف أين متى لما ولما أنما إنهم إنه إنها وإن وإذا فإن فإذا ولا ولم ولن فلا فلم""".split()}
GRAM = ("مفعول","خبر","حال","نعت","مبتدأ","مبتدا","فاعل","بدل","عطف","جواب","ظرف","تمييز","زائد","استفهام","نافية",
        "ناهية","شرطية","موصول","للتحقيق","للتعليل","للتأكيد","بالياء","بالتاء","بالمد","بالقصر","بالتخفيف","بالتشديد",
        "بالفتح","بالكسر","بالضم","بالنون","قراءة","همزة","الواو","الفاء","حرف","متعلق","اسم","صفة","منصوب","مرفوع",
        "مجرور","مصدر","تأكيد","توكيد","للتنبيه","للعطف","استئناف","جملة","لام","نون","ياء","تاء","ضمير","مفعوله","مقدر",
        "معنى","بمعنى","نائب","محل","إعراب","صلة","الخ","أصله")
PREP = {"في","من","على","إلى","عن","بأن","أن","لأن","مع","ب","ل","و","ف","ك","لمن","بمن","ما","لا","لم","لن","إن","إذ","إذا","هل","كيف"}
# ضمائر/ربط تدل على أن العبارة شرح للسياق لا مرادف للكلمة
PRON = {"فيها","فيه","منه","منها","به","بها","لهم","لها","له","عنهم","عنه","عليه","عليهم","عليها","بهم","إليه","إليها","إليهم","لهن","منهم","هم","هو","هي","هذا","ذلك","المذكور","المذكورة","ذكر","ذكره","ذكرها"}
MAXTOK = 3  # دقة أعلى: مرادف أو عبارة قصيرة فقط

def loose(w):
    w = normalize(w)
    for x, y in (("ى", "ي"), ("ة", "ه"), ("ؤ", "و"), ("ئ", "ي"), ("ء", "")): w = w.replace(x, y)
    return w

def cmd_glosses(a):
    import random
    jal = read_pipe(a.input)
    quran = {}
    for s_ in load_quran(a.quran):
        for ay in s_["ayahs"]: quran[(s_["number"], ay["n"])] = ay["t"].split()
    span = re.compile(r"«([^»]+)»\s*([^«]*)")
    out, kept, seen = {}, 0, 0
    for (s_, v), t in sorted(jal.items()):
        for m in span.finditer(t):
            ph = m.group(1).split()
            if len(ph) != 1: continue
            seen += 1
            wn = normalize(ph[0])
            if len(wn) < 3 or wn in STOP or (wn[0] in "وف" and normalize(wn[1:]) in STOP): continue
            g = re.split(r"[.،:؛()\[\]]", m.group(2))[0].strip()
            g = re.sub(r"^(?:أي|هو|وهو|هي|وهي)\s+", "", g).strip()
            toks = g.split()
            if not (1 <= len(toks) <= MAXTOK) or toks[0] in PREP or any(tk in PRON for tk in toks): continue
            if any(tk.startswith(x) for tk in toks for x in GRAM): continue
            lg, lw = loose(g), loose(ph[0])
            if len(toks) == 1 and (lg.endswith(lw) or lw.endswith(lg) or lw in lg or lg in lw): continue
            key = next((normalize(w) for w in quran.get((s_, v), []) if loose(w) == lw), None)
            if not key or len(key) < 2: continue
            slot = out.setdefault(f"{s_}:{v}", {})
            if key not in slot: slot[key] = g; kept += 1
    final = {"_source": SOURCES["ar.jalalayn"] + " - extracted word glosses (per ayah context)"}
    final.update(out)
    Path(a.output).write_text(json.dumps(final, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(f"أقواس مفردة في الجلالين: {seen} | معانٍ محفوظة: {kept} في {len(out)} آية -> {a.output}")
    random.seed(11)
    flat = [(k, w, g) for k, d in out.items() for w, g in d.items()]
    for k, w, g in random.sample(flat, min(40, len(flat))): print(f"  {k}  {w} => {g}")

def cmd_demo(a):
    d = Path(a.outdir); d.mkdir(parents=True, exist_ok=True)
    surahs = [{"number": i, "name": nm, "ayahs": [
        {"n": n, "t": f"نَصٌّ تَجْرِيبِيٌّ لِاخْتِبَارِ الْوَاجِهَةِ رَقْمُ {n}"} for n in range(1, c + 1)]}
        for i, (nm, c) in enumerate(zip(NAMES, AYAH_COUNTS), start=1)]
    (d / "quran.json").write_text(json.dumps({"basmala": "بسملة تجريبية", "surahs": surahs},
                                             ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    (d / "meanings.json").write_text(json.dumps({"تجريبي": "كلمة تجريبية لاختبار النافذة السفلية"},
                                                ensure_ascii=False), encoding="utf-8")
    print(f"تم إنشاء بيانات تجريبية في {d}\nتنبيه: هذه ليست نص القرآن، استبدلها بالبيانات الحقيقية قبل أي استخدام.")

if __name__ == "__main__":
    assert len(NAMES) == 114 and len(AYAH_COUNTS) == 114 and sum(AYAH_COUNTS) == 6236
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    for name, fn in [("quran", cmd_quran), ("words", cmd_words), ("meanings", cmd_meanings)]:
        p = sp.add_parser(name); p.add_argument("input"); p.add_argument("output"); p.set_defaults(fn=fn)
    p = sp.add_parser("tafsir"); p.add_argument("input"); p.add_argument("output"); p.set_defaults(fn=cmd_tafsir)
    p = sp.add_parser("glosses"); p.add_argument("input"); p.add_argument("quran"); p.add_argument("output"); p.set_defaults(fn=cmd_glosses)
    p = sp.add_parser("demo"); p.add_argument("outdir"); p.set_defaults(fn=cmd_demo)
    p = sp.add_parser("validate"); p.add_argument("input"); p.add_argument("--meanings"); p.set_defaults(fn=cmd_validate)
    a = ap.parse_args(); a.fn(a)
