package com.quranapp.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.quranapp.ui.reader.ReaderViewModel
import com.quranapp.ui.theme.Gold
import com.quranapp.ui.theme.GoldSoft

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: ReaderViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val hasMeanings by vm.hasMeanings.collectAsStateWithLifecycle()
    val dark = s.dark ?: isSystemInDarkTheme()
    val gharib = s.tafsirSource == "gharib" && hasMeanings

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = { Text("الضبط", color = Gold) },
                    navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = Gold) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )
            }
        ) { pad ->
            Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp)) {
                Section("المظهر")
                Row(
                    Modifier.fillMaxWidth().clickable { vm.setDark(!dark) }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("الوضع الليلي", Modifier.weight(1f), fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurface)
                    Switch(
                        checked = dark, onCheckedChange = { vm.setDark(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = Gold)
                    )
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Gold.copy(alpha = 0.25f))

                Section("عند الضغط المطوّل على الآية أو الكلمة")
                SourceRow(
                    "التفسير الميسر", "يعرض تفسير الآية (مجمع الملك فهد)",
                    selected = !gharib, enabled = true
                ) { vm.setTafsirSource("muyassar") }
                SourceRow(
                    "غريب القرآن",
                    if (hasMeanings) "معاني الكلمات المفردة: تظهر الكلمة مسطّرة، وبالنقر يظهر معناها"
                    else "غير متوفر حالياً — أضف ملف meanings.json إلى مجلد assets",
                    selected = gharib, enabled = hasMeanings
                ) { vm.setTafsirSource("gharib") }
                HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Gold.copy(alpha = 0.25f))

                Section("عن التطبيق")
                Text(
                    "نص المصحف والتفسير الميسر (مجمع الملك فهد): مشروع تنزيل Tanzil — tanzil.net. يعمل التطبيق بدون إنترنت.",
                    fontSize = 14.sp, lineHeight = 24.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                )
            }
        }
    }
}

@Composable
private fun Section(t: String) {
    Text(t, Modifier.padding(top = 8.dp, bottom = 4.dp), color = Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
}

@Composable
private fun SourceRow(title: String, sub: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val alpha = if (enabled) 1f else 0.45f
    Row(
        Modifier.fillMaxWidth()
            .selectable(selected = selected, enabled = enabled, role = Role.RadioButton, onClick = onClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected, onClick = null, enabled = enabled,
            colors = RadioButtonDefaults.colors(selectedColor = Gold, unselectedColor = GoldSoft)
        )
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = alpha))
            Text(sub, fontSize = 13.sp, color = GoldSoft.copy(alpha = alpha))
        }
    }
}
