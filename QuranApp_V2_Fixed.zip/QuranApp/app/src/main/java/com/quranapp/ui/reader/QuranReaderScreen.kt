package com.quranapp.ui.reader

import android.app.Activity
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.quranapp.data.Ayah
import com.quranapp.data.QuranMarks
import com.quranapp.ui.index.QuickNavDialog
import com.quranapp.ui.theme.*
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.debounce
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/** عدد الآيات في كل فقرة متصلة (لأداء التمرير مع السور الطويلة). */
private const val CHUNK = 6
private val NO_MEANING: (String) -> String? = { null }

private data class AyahSheet(val surah: Int, val ayah: Int, val word: String)

@OptIn(ExperimentalMaterial3Api::class, FlowPreview::class)
@Composable
fun QuranReaderScreen(vm: ReaderViewModel, onOpenIndex: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val opened by vm.opened.collectAsStateWithLifecycle()
    val index by vm.index.collectAsStateWithLifecycle()
    val hasMeanings by vm.hasMeanings.collectAsStateWithLifecycle()
    val surah = opened?.surah
    val startAyah = opened?.startAyah
    val gharib = s.tafsirSource == "gharib" && hasMeanings

    val dark = s.dark ?: isSystemInDarkTheme()
    val bgOptions = ReaderBackground.forMode(dark)
    val bg = bgOptions[s.bgIndex.coerceIn(0, bgOptions.lastIndex)]
    val minF = MIN_FONT_UNIT.toFloat()
    val maxF = MAX_FONT_UNIT.toFloat()

    var barsVisible by rememberSaveable { mutableStateOf(true) }
    var autoScroll by rememberSaveable { mutableStateOf(false) }
    var showFont by remember { mutableStateOf(false) }
    var showQuick by remember { mutableStateOf(false) }
    var sheet by remember { mutableStateOf<AyahSheet?>(null) }

    var liveSize by remember { mutableFloatStateOf(s.fontSize.toFloat().coerceIn(minF, maxF)) }
    LaunchedEffect(s.fontSize) { liveSize = s.fontSize.toFloat().coerceIn(minF, maxF) }
    var liveSpeed by remember { mutableFloatStateOf(s.speed) }
    LaunchedEffect(s.speed) { liveSpeed = s.speed }

    val chunks = remember(surah) { surah?.ayahs?.chunked(CHUNK) ?: emptyList() }
    val bookmarked = remember(s.bookmarks, surah?.number) {
        s.bookmarks.mapNotNull { b ->
            val p = b.split(":")
            if (p.getOrNull(0)?.toIntOrNull() == surah?.number) p.getOrNull(1)?.toIntOrNull() else null
        }.toSet()
    }

    val listState = rememberLazyListState()
    val density = LocalDensity.current.density
    val pxPerSec by rememberUpdatedState((15f + liveSpeed * 250f) * density)
    val firstAyah by remember(surah) {
        derivedStateOf {
            chunks.getOrNull((listState.firstVisibleItemIndex - 1).coerceAtLeast(0))?.firstOrNull()?.number ?: 1
        }
    }

    ImmersiveEffect(immersive = !barsVisible)

    LaunchedEffect(surah?.number, startAyah) {
        val sr = surah ?: return@LaunchedEffect
        val idx = sr.ayahs.indexOfFirst { it.number == startAyah }
        listState.scrollToItem(if (startAyah == null || idx < 0) 0 else idx / CHUNK + 1)
    }

    LaunchedEffect(surah?.number) {
        val sr = surah ?: return@LaunchedEffect
        snapshotFlow { listState.firstVisibleItemIndex }
            .debounce(800)
            .collect { i ->
                chunks.getOrNull((i - 1).coerceAtLeast(0))?.firstOrNull()?.let { vm.saveProgress(sr.number, it.number) }
            }
    }

    LaunchedEffect(Unit) {
        listState.interactionSource.interactions.collect { if (it is DragInteraction.Start) autoScroll = false }
    }

    LaunchedEffect(autoScroll) {
        if (!autoScroll) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = (now - last) / 1_000_000_000f
            last = now
            listState.scrollBy(pxPerSec * dt)
            if (!listState.canScrollForward) { autoScroll = false; break }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            Modifier.fillMaxSize().background(bg.color)
                .pinchToZoom(
                    onZoom = { liveSize = (liveSize * it).coerceIn(minF, maxF) },
                    onEnd = { vm.setFont(((liveSize / 2).roundToInt() * 2).coerceIn(MIN_FONT_UNIT, MAX_FONT_UNIT)) }
                )
        ) {
            if (surah != null) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 104.dp)
                ) {
                    item(key = "header") {
                        Column(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                            Text(
                                "سورة ${surah.name}", color = Gold, fontFamily = LocalQuranFont.current,
                                fontSize = 30.sp, textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                                    .border(1.dp, Gold, RoundedCornerShape(12.dp)).padding(12.dp)
                            )
                            surah.basmala?.let { b ->
                                Text(
                                    b, color = bg.text, fontFamily = LocalQuranFont.current,
                                    fontSize = (liveSize * 0.9f).sp, textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
                                )
                            }
                        }
                    }
                    items(chunks.size, key = { it }) { i ->
                        AyahParagraph(
                            ayahs = chunks[i], fontSize = liveSize, color = bg.text,
                            bookmarked = bookmarked, underline = gharib,
                            meaningOf = if (gharib) vm::meaningOf else NO_MEANING,
                            onWordTap = { n, w -> sheet = AyahSheet(surah.number, n, w) },
                            onTapBlank = { barsVisible = !barsVisible },
                            onLong = { n, w -> sheet = AyahSheet(surah.number, n, w) },
                        )
                    }
                }
            } else {
                CircularProgressIndicator(Modifier.align(Alignment.Center), color = Gold)
            }

            AnimatedVisibility(
                visible = barsVisible, modifier = Modifier.align(Alignment.TopCenter),
                enter = fadeIn() + slideInVertically { -it }, exit = fadeOut() + slideOutVertically { -it }
            ) {
                TopBar(
                    title = surah?.name ?: "",
                    subtitle = surah?.let { QuranMarks.label(it.number, firstAyah) } ?: "",
                    bgOptions = bgOptions, bgIndex = s.bgIndex,
                    onIndex = onOpenIndex, onQuick = { showQuick = true },
                    onFont = { showFont = true }, onBg = vm::setBg
                )
            }

            AnimatedVisibility(
                visible = barsVisible, modifier = Modifier.align(Alignment.BottomCenter),
                enter = fadeIn() + slideInVertically { it }, exit = fadeOut() + slideOutVertically { it }
            ) {
                BottomBar(
                    autoScroll = autoScroll, onToggle = { autoScroll = !autoScroll },
                    speed = liveSpeed, onSpeed = { liveSpeed = it }, onSpeedDone = { vm.setSpeed(liveSpeed) }
                )
            }
        }

        if (showFont) FontSizeDialog(
            current = ((liveSize / 2).roundToInt() * 2).coerceIn(MIN_FONT_UNIT, MAX_FONT_UNIT),
            onSelect = { vm.setFont(it); liveSize = it.toFloat(); showFont = false },
            onDismiss = { showFont = false }
        )

        if (showQuick) QuickNavDialog(
            index = index,
            onGo = { sn, an -> vm.openSurah(sn, an); showQuick = false },
            onDismiss = { showQuick = false }
        )

        sheet?.let { sh ->
            val isBm = sh.ayah in bookmarked
            val tafsir by produceState("جارٍ التحميل…", sh.surah, sh.ayah, gharib) {
                value = if (gharib) "" else
                    vm.tafsirOf(sh.surah, sh.ayah) ?: "لا يتوفر تفسير لهذه الآية (تأكد من وجود tafsir.json في assets)"
            }
            ModalBottomSheet(onDismissRequest = { sheet = null }) {
                Column(
                    Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                        .padding(24.dp).navigationBarsPadding(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("سورة ${surah?.name ?: ""} · الآية ${QuranMarks.ar(sh.ayah)}", color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(QuranMarks.label(sh.surah, sh.ayah), fontSize = 13.sp, color = GoldSoft)
                    HorizontalDivider(Modifier.padding(vertical = 12.dp), color = Gold)
                    if (gharib) {
                        Text("غريب القرآن", fontSize = 13.sp, color = GoldSoft)
                        Text(sh.word, fontFamily = LocalQuranFont.current, fontSize = 32.sp, color = Gold)
                        Text(
                            vm.meaningOf(sh.word) ?: "لا يتوفر معنى لهذه الكلمة",
                            fontSize = 18.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface
                        )
                    } else {
                        Text("تفسير الآية — التفسير الميسر", fontSize = 13.sp, color = GoldSoft)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            tafsir, fontSize = 17.sp, lineHeight = 28.sp, textAlign = TextAlign.Justify,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = { vm.toggleBookmark(sh.surah, sh.ayah) },
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)
                    ) {
                        Icon(if (isBm) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (isBm) "إزالة الإشارة المرجعية" else "إضافة إشارة مرجعية")
                    }
                }
            }
        }
    }
}

/* ------------------- فقرة متصلة بدون فواصل + رقم آية مزخرف ------------------- */

@Composable
private fun AyahParagraph(
    ayahs: List<Ayah>, fontSize: Float, color: Color, bookmarked: Set<Int>, underline: Boolean,
    meaningOf: (String) -> String?,
    onWordTap: (Int, String) -> Unit, onTapBlank: () -> Unit, onLong: (Int, String) -> Unit,
) {
    val text = remember(ayahs, bookmarked, underline) {
        buildAnnotatedString {
            ayahs.forEach { ay ->
                val start = length
                ay.text.split(' ').forEachIndexed { i, w ->
                    if (i > 0) append(' ')
                    if (underline && meaningOf(w) != null)
                        withStyle(SpanStyle(color = GoldSoft, textDecoration = TextDecoration.Underline)) { append(w) }
                    else append(w)
                }
                append(' ')
                appendInlineContent("a${ay.number}", "﴿")
                val end = length
                addStringAnnotation("ayah", ay.number.toString(), start, end)
                if (ay.number in bookmarked) addStyle(SpanStyle(background = Gold.copy(alpha = 0.18f)), start, end)
                append(' ')
            }
        }
    }
    val inline = remember(ayahs, fontSize) {
        ayahs.associate { ay ->
            "a${ay.number}" to InlineTextContent(
                Placeholder((fontSize * 1.45f).sp, (fontSize * 1.45f).sp, PlaceholderVerticalAlign.Center)
            ) { _ -> Ornament(ay.number, fontSize) }
        }
    }
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }

    fun offsetAt(p: Offset): Int? = layout?.getOffsetForPosition(p)?.coerceIn(0, (text.length - 1).coerceAtLeast(0))
    fun ayahAt(o: Int): Int? = text.getStringAnnotations("ayah", o, o).firstOrNull()?.item?.toIntOrNull()
    fun wordAt(o: Int): String? {
        val t = text.text
        if (t.isEmpty()) return null
        var st = o; while (st > 0 && t[st - 1] != ' ') st--
        var en = o; while (en < t.length && t[en] != ' ') en++
        return t.substring(st, en).takeIf { it.isNotBlank() }
    }

    Text(
        text = text, inlineContent = inline, color = color, fontFamily = LocalQuranFont.current,
        fontSize = fontSize.sp, lineHeight = (fontSize * 1.95f).sp,
        textAlign = TextAlign.Justify,
        onTextLayout = { layout = it },
        modifier = Modifier.fillMaxWidth().pointerInput(text) {
            detectTapGestures(
                onTap = { p ->
                    val o = offsetAt(p)
                    val n = o?.let { ayahAt(it) }
                    val w = o?.let { wordAt(it) }
                    if (underline && n != null && w != null && meaningOf(w) != null) onWordTap(n, w) else onTapBlank()
                },
                onLongPress = { p ->
                    val o = offsetAt(p)
                    val n = o?.let { ayahAt(it) }
                    if (n != null) onLong(n, o?.let { wordAt(it) } ?: "")
                }
            )
        }
    )
}

/** رقم الآية داخل زخرفة دائرية ذهبية. */
@Composable
private fun Ornament(n: Int, fontSize: Float) {
    val boxSize = with(LocalDensity.current) { (fontSize * 1.45f).sp.toDp() }
    Box(Modifier.size(boxSize), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            drawCircle(Gold, radius = r * 0.74f, style = Stroke(r * 0.09f))
            drawCircle(GoldSoft, radius = r * 0.58f, style = Stroke(r * 0.04f))
            for (i in 0 until 12) {
                val a = Math.toRadians(i * 30.0)
                drawCircle(
                    Gold, radius = r * 0.085f,
                    center = Offset(center.x + (r * 0.9f * cos(a)).toFloat(), center.y + (r * 0.9f * sin(a)).toFloat())
                )
            }
        }
        Text(QuranMarks.ar(n), color = Gold, fontSize = (fontSize * 0.4f).sp, fontWeight = FontWeight.Bold)
    }
}

/* ---------------------------- الأشرطة ---------------------------- */

@Composable
private fun TopBar(
    title: String, subtitle: String, bgOptions: List<ReaderBackground>, bgIndex: Int,
    onIndex: () -> Unit, onQuick: () -> Unit, onFont: () -> Unit, onBg: (Int) -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Surface(color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f), shadowElevation = 4.dp) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onIndex) { Icon(Icons.Default.Menu, "الفهرس", tint = Gold) }
            Column(Modifier.weight(1f)) {
                Text(title, color = Gold, fontFamily = LocalQuranFont.current, fontSize = 22.sp, maxLines = 1)
                Text(subtitle, color = GoldSoft, fontSize = 12.sp, maxLines = 1)
            }
            IconButton(onQuick) { Icon(Icons.Default.Explore, "الانتقال السريع", tint = Gold) }
            IconButton(onFont) { Icon(Icons.Default.FormatSize, "حجم الخط", tint = Gold) }
            Box {
                IconButton({ menu = true }) { Icon(Icons.Default.Palette, "الخلفية", tint = Gold) }
                DropdownMenu(menu, { menu = false }) {
                    bgOptions.forEachIndexed { i, o ->
                        DropdownMenuItem(
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        Modifier.size(22.dp).clip(CircleShape).background(o.color)
                                            .border(if (i == bgIndex.coerceIn(0, bgOptions.lastIndex)) 2.dp else 1.dp, Gold, CircleShape)
                                    )
                                    Spacer(Modifier.width(10.dp)); Text(o.label)
                                }
                            },
                            onClick = { onBg(i); menu = false }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomBar(
    autoScroll: Boolean, onToggle: () -> Unit,
    speed: Float, onSpeed: (Float) -> Unit, onSpeedDone: () -> Unit,
) {
    Surface(color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f), shadowElevation = 8.dp) {
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onToggle, Modifier.size(52.dp)) {
                Icon(
                    if (autoScroll) Icons.Default.Pause else Icons.Default.PlayArrow,
                    "تمرير تلقائي", tint = Gold, modifier = Modifier.size(36.dp)
                )
            }
            Text("بطيء", fontSize = 12.sp, color = GoldSoft)
            Slider(
                value = speed, onValueChange = onSpeed, onValueChangeFinished = onSpeedDone,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                colors = SliderDefaults.colors(
                    thumbColor = Gold, activeTrackColor = Gold, inactiveTrackColor = Gold.copy(alpha = 0.3f)
                )
            )
            Text("سريع", fontSize = 12.sp, color = GoldSoft)
        }
    }
}

/* ---------------------------- أدوات مساعدة ---------------------------- */

@Composable
private fun ImmersiveEffect(immersive: Boolean) {
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window ?: return@SideEffect
        val c = WindowCompat.getInsetsController(window, view)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (immersive) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
    }
    DisposableEffect(Unit) {
        onDispose {
            (view.context as? Activity)?.window?.let {
                WindowCompat.getInsetsController(it, view).show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }
}

private fun Modifier.pinchToZoom(onZoom: (Float) -> Unit, onEnd: () -> Unit) =
    pointerInput(Unit) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false)
            var zoomed = false
            do {
                val ev = awaitPointerEvent(PointerEventPass.Initial)
                if (ev.changes.size >= 2) {
                    val z = ev.calculateZoom()
                    if (z != 1f) { onZoom(z); zoomed = true }
                    ev.changes.forEach { it.consume() }
                }
            } while (ev.changes.any { it.pressed })
            if (zoomed) onEnd()
        }
    }
