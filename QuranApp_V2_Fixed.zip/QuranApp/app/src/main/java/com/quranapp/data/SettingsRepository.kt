package com.quranapp.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore(name = "settings")

data class Settings(
    val fontSize: Int = 40,                 // وحدات الخط (20..80)
    val dark: Boolean? = null,              // null = حسب النظام
    val bgIndex: Int = 0,
    val speed: Float = 0.3f,                // سرعة التمرير التلقائي 0..1
    val lastSurah: Int = 0,                 // 0 = لا يوجد موضع محفوظ
    val lastAyah: Int = 1,
    val tafsirSource: String = "muyassar",  // muyassar | gharib
    val bookmarks: Set<String> = emptySet(), // "surah:ayah:time"
)

class SettingsRepository(private val ctx: Context) {
    private val FONT = intPreferencesKey("font")
    private val DARK = booleanPreferencesKey("dark")
    private val BG = intPreferencesKey("bg")
    private val SPEED = floatPreferencesKey("speed")
    private val LAST_SURAH = intPreferencesKey("last_surah")
    private val LAST_AYAH = intPreferencesKey("last_ayah")
    private val SOURCE = stringPreferencesKey("tafsir_source")
    private val BM = stringSetPreferencesKey("bookmarks")

    val flow = ctx.store.data.map { p ->
        Settings(
            fontSize = (p[FONT] ?: 40).coerceIn(20, 80),
            dark = p[DARK],
            bgIndex = p[BG] ?: 0,
            speed = p[SPEED] ?: 0.3f,
            lastSurah = p[LAST_SURAH] ?: 0,
            lastAyah = p[LAST_AYAH] ?: 1,
            tafsirSource = p[SOURCE] ?: "muyassar",
            bookmarks = p[BM] ?: emptySet(),
        )
    }

    suspend fun setFont(v: Int) = ctx.store.edit { it[FONT] = v }
    suspend fun setDark(v: Boolean) = ctx.store.edit { it[DARK] = v }
    suspend fun setBg(v: Int) = ctx.store.edit { it[BG] = v }
    suspend fun setSpeed(v: Float) = ctx.store.edit { it[SPEED] = v }
    suspend fun setTafsirSource(v: String) = ctx.store.edit { it[SOURCE] = v }
    suspend fun setLastRead(surah: Int, ayah: Int) = ctx.store.edit {
        it[LAST_SURAH] = surah; it[LAST_AYAH] = ayah
    }

    /** يضيف الإشارة إن لم تكن موجودة، ويحذفها إن كانت موجودة. */
    suspend fun toggleBookmark(surah: Int, ayah: Int) = ctx.store.edit { prefs ->
        val cur = prefs[BM] ?: emptySet()
        val prefix = "$surah:$ayah:"
        val existing = cur.filter { b -> b.startsWith(prefix) }.toSet()
        prefs[BM] = if (existing.isNotEmpty()) cur - existing else cur + "$prefix${System.currentTimeMillis()}"
    }
}
