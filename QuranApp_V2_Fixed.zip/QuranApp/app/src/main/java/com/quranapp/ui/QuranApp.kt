package com.quranapp.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.quranapp.ui.index.SurahIndexScreen
import com.quranapp.ui.reader.QuranReaderScreen
import com.quranapp.ui.reader.ReaderViewModel
import com.quranapp.ui.settings.SettingsScreen
import com.quranapp.ui.theme.QuranTheme

enum class Screen { Index, Reader, Settings }

/** تنقّل بسيط: الفهرس ⇄ القارئ ⇄ الضبط مع زر الرجوع. ViewModel واحد مشترك. */
@Composable
fun QuranApp(vm: ReaderViewModel = viewModel()) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val opened by vm.opened.collectAsStateWithLifecycle()
    val dark = s.dark ?: isSystemInDarkTheme()

    var screen by rememberSaveable { mutableStateOf(Screen.Index) }
    // يحمي من استعادة شاشة القراءة بعد قتل العملية دون سورة مفتوحة
    val current = if (screen == Screen.Reader && opened == null) Screen.Index else screen

    BackHandler(enabled = current != Screen.Index) { screen = Screen.Index }

    QuranTheme(dark = dark) {
        Crossfade(targetState = current, label = "screen") { sc ->
            when (sc) {
                Screen.Reader -> QuranReaderScreen(vm, onOpenIndex = { screen = Screen.Index })
                Screen.Settings -> SettingsScreen(vm, onBack = { screen = Screen.Index })
                Screen.Index -> SurahIndexScreen(
                    vm,
                    onOpen = { surah, ayah -> vm.openSurah(surah, ayah); screen = Screen.Reader },
                    onSettings = { screen = Screen.Settings }
                )
            }
        }
    }
}
